<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database('default', true);
        $this->load->model(array('admin_model'));
    }

	public function index()
	{

		$data['data'] = $this->admin_model->get_kp_all();

		//print_r($data);



		$this->load->view('admin', $data);
	}
}
