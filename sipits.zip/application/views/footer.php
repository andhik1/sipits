<div class="footer">
    <div class="container no-padding">
        <div class="col-md-2 col-sm-2">
            <h4><strong>Sitemap</strong></h4>
            <ul class="list-unstyled">
                <li><a href="https://simpel.its.ac.id/">Halaman Utama</a></li>
                <li><a href="https://simpel.its.ac.id/index.php/home/pencarian">Pencarian</a></li>
                <li><a href="https://simpel.its.ac.id/index.php/home/berita">Berita Terbaru</a></li>
                <li><a href="https://simpel.its.ac.id/index.php/home/tentang">Tentang</a></li>
                <li><a href="https://simpel.its.ac.id/index.php/login">Login</a></li>
            </ul>
        </div>
        <div class="col-md-6 col-sm-6">
            <h4><strong>Contact Us</strong></h4>
            <div class="col-md-6 no-padding">
                <address>
                    <strong>LPPM-ITS</strong><br>
                    Gedung Pusat Riset Lantai Lobby, Kampus ITS Sukolilo - Surabaya 60111<br>
                    <abbr title="phone">Tlp:</abbr> 031 - 5953759<br>
                </address>
            </div>
            <div class="col-md-6 col-sm-6">
                <address>
                    <strong>PABX</strong><br>
                    LPPM ITS : 1404 / 1405 atau melalui https://servicedesk.its.ac.id/ dengan pilihan unit tujuan yaitu "Lembaga Penelitian dan Pengabdian Kepada Masyarakat"                    <strong>Website</strong><br>
                    <a href="http://https//www.its.ac.id/lppm">https://www.its.ac.id/lppm</a><br>
                    <strong>Email</strong><br>
                    <a href="mailto:lppm@its.ac.id">lppm@its.ac.id</a>
                    </address>
                    <a href="mailto:lppm@its.ac.id"></a>
        </div><a href="mailto:lppm@its.ac.id">
        </a></div><a href="mailto:lppm@its.ac.id">
        </a><div class="col-md-4 col-sm-4 text-center"><a href="mailto:lppm@its.ac.id">
            </a><a href="http://www.lppm.its.ac.id/"><img src="./sipits2_files/lppm-logo.png"></a>
            <a href="http://www.its.ac.id/" style="padding-top: 5px;"><img src="./sipits2_files/its-logo.png"></a>
        </div>
        <div class="clearfix"></div>
        <div class="col-md-12 col-sm-12 text-center copy">
            Copyright © 2019 SIPITS 1.0 LPPM ITS. Developed by DPTSI ITS.
        </div>
    </div>
</div>