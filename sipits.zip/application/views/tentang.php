<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html lang="en">
<head>

    <?php include("header.php") ?>

    
    <?php include("stile.php") ?>

    <style type="text/css">
    	h1{
    		font-size: 20px;
    	}


    </style>
</head>
<body>
    <div class="container-fluid">

    <div class="row header">
         <?php include("menu_bar.php") ?>
       
    </div>

    <div class="clearfix"></div>


<h1>Tentang SIPITS</h1>
Sistem Informasi pendataan ITS (SIPITS) saat ini masih dalam masa development. Sistem ini digunakan untuk membantu LPPM untuk mengelola dan memonitoring kegiatan civitas akademika baik untuk internal ITS maupun eksternal ITS. Dalam pembangunan pertama ini, SIPITS membantu pendaftaran untuk 4 program diantaranya : <br>
1. Pengadaan Asisten Peneliti (PAP)<br>
2. Klinik Makalah Publikasi Ilmiah (KMPI)<br>
3. Kerjasama Penelitian (KP)<br>
4. Program percepatan Publikasi Ilmiah (P3I)<br>
<br>
untuk informasi lebih lanjut, dapat menghubungi pihak LPPM ITS.

 </div>

 <?php include("footer.php") ?>


</body>
</html>

