    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>SIPITS | Sistem Informasi Pendataan ITS</title>

    <link rel="icon" type="image/png" sizes="16x16" href="https://simpel.its.ac.id/assets/img/simpel-icon.png">
    <link href="<?php echo base_url('assets/bahan/css');?>" rel="stylesheet">

    <link href="<?php echo base_url('assets/bahan/bootstrap.min.css');?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/bahan/stylesheet.css');?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/bahan/jquery.dataTables.min.css');?>" rel="stylesheet" type="text/css">

    <script src="<?php echo base_url('assets/bahan/jquery.min.js.download');?>"></script>

    <script src="<?php echo base_url('assets/bahan/bootstrap.min.js.download');?>"></script>

    <script src="<?php echo base_url('assets/bahan/jquery.dataTables.min.js.download');?>"></script>
    <script src="<?php echo base_url('assets/bahan/dataTables.bootstrap.min.js.download');?>"></script>

    
